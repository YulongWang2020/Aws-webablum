import json
import boto3
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import datetime

def lambda_handler(event, context):
    # TODO implement
    rekognition = boto3.client('rekognition')
    s3 = event["Records"][0]["s3"]
    bucket = s3["bucket"]["name"]
    name = s3["object"]["key"]
    # s3_client = boto3.client('s3')
    # response = s3_client.get_object(
    #     Bucket='photo-album-aws',
    #     Key='YulongWang.jpg',
    # )

    
    
    response = rekognition.detect_labels(
    Image={
        'S3Object': {
            'Bucket':bucket,
            'Name': name,
        }
    },
    MaxLabels=123,
    MinConfidence=70
)
    print(response)
    label = []
    for each in response["Labels"]:
        label.append(each["Name"])
        
        
    host = 'vpc-photo3-47u6chthqboavywymycm6kgz34.us-east-1.es.amazonaws.com'  # For example, my-test-domain.us-east-1.es.amazonaws.com
    
    region = 'us-east-1'  # e.g. us-west-1

    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    es = Elasticsearch(
        hosts=[{'host': host, 'port': 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        connection_class=RequestsHttpConnection
    )
    
    es.index(index="photos", doc_type="photo", body={"objectKey": name, "bucket":bucket,"createdTimestamp":datetime.datetime.now(),"labels":label})
    print("label: ",label)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

